import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Article } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBlogPosts = async (count: number = 6): Promise<Article[]> => {
  const schema: Schema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING },
        excerpt: { type: Type.STRING },
        content: { type: Type.STRING },
        author: { type: Type.STRING },
        date: { type: Type.STRING },
        category: { type: Type.STRING },
      },
      required: ["title", "excerpt", "content", "author", "date", "category"],
    },
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate ${count} engaging, diverse blog post articles. 
      Topics should vary between Technology, Nature, Travel, and Design.
      The 'content' field should be at least 3 paragraphs long formatted with \\n for line breaks.
      Dates should be recent formatted strings.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "You are a professional blog content writer for a high-end magazine.",
      },
    });

    const data = JSON.parse(response.text || "[]");
    
    // Add IDs to the generated items
    return data.map((item: any, index: number) => ({
      ...item,
      id: `gen-${Date.now()}-${index}`,
    }));
  } catch (error) {
    console.error("Error generating articles:", error);
    return [];
  }
};